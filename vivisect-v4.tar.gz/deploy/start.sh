#!/bin/bash
cd /opt/vivisect/web
nohup luajit server.lua > /var/log/vivisect.log 2>&1 &
echo $! > /var/run/vivisect.pid
echo "[+] Vivisect running on port 8080"
