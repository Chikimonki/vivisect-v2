-- lib/rop.lua - ROP gadget finder

local M = {}

-- Common useful gadgets
local patterns = {
    pop_rax_ret = "\x58\xc3",           -- pop rax ; ret
    pop_rdi_ret = "\x5f\xc3",           -- pop rdi ; ret
    pop_rsi_ret = "\x5e\xc3",           -- pop rsi ; ret
    pop_rdx_ret = "\x5a\xc3",           -- pop rdx ; ret
    syscall_ret = "\x0f\x05\xc3",       -- syscall ; ret
    mov_rax_rdi_ret = "\x48\x89\xf8\xc3", -- mov rax, rdi ; ret
}

function M.find_gadgets(binary_path)
    local f = io.open(binary_path, "rb")
    if not f then return {} end
    
    local data = f:read("*a")
    f:close()
    
    local gadgets = {}
    
    for name, pattern in pairs(patterns) do
        local pos = 1
        while true do
            local start = data:find(pattern, pos, true)
            if not start then break end
            
            -- Check if this is a valid executable address
            local addr = start - 1  -- 0-based index
            if addr >= 0x400000 then
                table.insert(gadgets, {
                    name = name,
                    address = addr,
                    bytes = pattern
                })
            end
            
            pos = start + 1
        end
    end
    
    return gadgets
end

function M.print_gadgets(gadgets)
    print("\n┌─ Found ROP Gadgets ──────────────────┐")
    for _, g in ipairs(gadgets) do
        print(string.format("│ 0x%08X  %s", g.address, g.name))
    end
    print(string.format("└──────────────────────────────────────┘\nFound %d gadgets", #gadgets))
end

return M
